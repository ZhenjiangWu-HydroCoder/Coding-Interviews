from typing import List


class Solution:
    def exchange(self, nums: List[int]) -> List[int]:
        if not nums: return []
        i, j = 0, len(nums) - 1
        while i < j:
            while i < j and nums[i] % 2 == 1: i += 1
            while i < j and nums[j] % 2 == 0: j -= 1
            if i < j:
                nums[i], nums[j] = nums[j], nums[i]
        return nums


if __name__ == "__main__":
    nums = [1, 2, 3, 4]
    solution = Solution()
    print(solution.exchange(nums))
