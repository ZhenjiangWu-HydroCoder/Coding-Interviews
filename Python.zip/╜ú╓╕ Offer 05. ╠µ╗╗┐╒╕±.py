class Solution:
    def replaceSpace(self, s: str) -> str:
        return "%20".join(s.split(" "))


if __name__ == "__main__":
    solution = Solution()
    print(solution.replaceSpace("We are happy."))
