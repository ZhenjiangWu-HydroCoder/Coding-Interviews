from typing import List


class Solution:
    @staticmethod
    def findRepeatNumber(nums: List[int]) -> int:
        if not nums: return -1
        i = 0
        while i < len(nums):
            if nums[i] == i:
                i += 1
                continue
            if nums[nums[i]] == nums[i]: return nums[i]
            nums[nums[i]], nums[i] = nums[i], nums[nums[i]]
        return -1


if __name__ == "__main__":
    nums: List[int] = [2, 3, 1, 0, 2, 5, 3]
    solution: Solution = Solution()
    print(solution.findRepeatNumber(nums=nums))
