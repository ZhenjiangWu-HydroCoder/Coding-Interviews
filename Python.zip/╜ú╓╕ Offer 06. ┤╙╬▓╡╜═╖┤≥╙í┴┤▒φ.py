from typing import List


class ListNode:
    def __init__(self, x):
        self.val = x
        self.next = None


class Solution:
    def reversePrint(self, head: ListNode) -> List[int]:
        stack = []
        p = head
        while p:
            stack.append(p.val)
            p = p.next
        return stack[::-1]
