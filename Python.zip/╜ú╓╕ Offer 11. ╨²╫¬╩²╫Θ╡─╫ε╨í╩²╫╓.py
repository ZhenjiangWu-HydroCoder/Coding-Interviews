from typing import List


class Solution:
    def minArray(self, numbers: List[int]) -> int:
        if not numbers: return -1
        n = len(numbers) - 1
        while n and numbers[0] == numbers[n]: n -= 1
        if numbers[0] <= numbers[n]: return numbers[0]
        l = 0
        r = n
        while l < r:
            mid = l + r >> 1
            if numbers[mid] < numbers[0]:
                r = mid
            else:
                l = mid + 1
        return numbers[r]


if __name__ == "__main__":
    numbers = [3, 4, 5, 1, 2]
    solution = Solution()
    print(solution.minArray(numbers))
