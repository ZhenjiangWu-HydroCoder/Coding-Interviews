class ListNode:
    def __init__(self, x):
        self.val = x
        self.next = None


class Solution:
    def reverseList(self, head: ListNode) -> ListNode:
        if not head: return head
        a = head
        b = head.next
        while b:
            c = b.next
            b.next = a
            a = b
            b = c
        head.next = None
        return a
