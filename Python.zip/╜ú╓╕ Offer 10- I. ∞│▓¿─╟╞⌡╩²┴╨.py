class Solution:
    def fib(self, n: int) -> int:
        a, b = 0, 1
        for i in range(n):
            a, b = b, a + b
        return a % 1000000007


if __name__ == "__main__":
    solution = Solution()
    print(solution.fib(92))
