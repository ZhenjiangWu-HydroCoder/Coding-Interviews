class CQueue:

    def __init__(self):
        self.stack = []
        self.cache = []

    def appendTail(self, value: int) -> None:
        self.stack.append(value)

    def deleteHead(self) -> int:
        if self.cache: return self.cache.pop()
        if not self.stack: return -1
        while self.stack:
            self.cache.append(self.stack.pop())
        return self.cache.pop()
