﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 剑指_Offer_10__I.斐波那契数列
{
    public class Solution
    {
        public int Fib(int n)
        {
            const int mod = 1000000007;
            int a, b, tmp;
            a = 0;
            b = 1;
            for (int i = 0; i < n; i++) {
                tmp = a;
                a = b;
                b = (tmp + b) % mod;
            }
            return a;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Solution solution = new Solution();
            Console.WriteLine(solution.Fib(92));
        }
    }
}
