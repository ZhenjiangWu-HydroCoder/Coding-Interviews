﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 剑指_Offer_07.重建二叉树
{
    public class TreeNode
    {
        public int val;
        public TreeNode left;
        public TreeNode right;
        public TreeNode(int x) { val = x; }
    }

    public class Solution
    {
        public TreeNode BuildTree(int[] preorder, int[] inorder)
        {
            if (preorder.Length == 0 || inorder.Length == 0) return null;
            TreeNode node = new TreeNode(preorder[0]);
            int index = Array.IndexOf(inorder, preorder[0]);
            int[] left_pre = preorder.Skip(1).Take(index + 1).ToArray();
            int[] left_in = inorder.Skip(0).Take(index).ToArray();
            int[] right_pre = preorder.Skip(index + 1).ToArray();
            int[] right_in = inorder.Skip(index + 1).ToArray();
            node.left = BuildTree(left_pre, left_in);
            node.right = BuildTree(right_pre, right_in);
            return node;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
