﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 剑指_Offer_24.反转链表
{
    public class ListNode
    {
        public int val;
        public ListNode next;
        public ListNode(int x) { val = x; }
    }
    public class Solution
    {
        public ListNode ReverseList(ListNode head)
        {
            if (head == null) return null;
            var a = head;
            var b = head.next;
            while (b != null) {
                var c = b.next;
                b.next = a;
                a = b;
                b = c;
            }
            head.next = null;
            return a;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
