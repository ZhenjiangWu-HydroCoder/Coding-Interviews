﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 剑指_Offer_18.删除链表的节点
{
    public class ListNode
    {
        public int val;
        public ListNode next;
        public ListNode(int x) { val = x; }
    }
    public class Solution
    {
        public ListNode DeleteNode(ListNode head, int val)
        {
            if (head.val == val) {
                return head.next;
            }
            ListNode pre = head;
            ListNode cur = head.next;
            while (cur != null && cur.val != val) {
                pre = pre.next;
                cur = cur.next;
            }
            if (cur != null) {
                pre.next = cur.next;
            }
            return head;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
