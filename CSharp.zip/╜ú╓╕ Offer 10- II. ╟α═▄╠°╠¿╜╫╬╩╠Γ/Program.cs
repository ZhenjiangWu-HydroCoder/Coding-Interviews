﻿using System;

namespace 剑指_Offer_10__II.青蛙跳台阶问题
{
    public class Solution
    {
        public int NumWays(int n)
        {
            int a, b, tmp;
            a = b = 1;
            for (int i = 0; i < n; i++) {
                tmp = a;
                a = b;
                b = (tmp + b) % 1000000007;
            }
            return a;

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Solution solution = new Solution();
            Console.WriteLine(solution.NumWays(92));
        }
    }
}
