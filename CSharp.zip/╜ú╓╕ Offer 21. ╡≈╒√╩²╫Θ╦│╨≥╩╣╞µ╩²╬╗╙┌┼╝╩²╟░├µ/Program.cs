﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 剑指_Offer_21.调整数组顺序使奇数位于偶数前面
{
    public class Solution
    {
        public int[] Exchange(int[] nums)
        {
            if (nums.Length == 0) {
                int[] ans = new int[0];
                return ans;
            }
            int i = 0;
            int j = nums.Length - 1;
            while (i < j) {
                while (i < j && nums[i] % 2 == 1) {
                    i++;
                }
                while (i < j && nums[j] % 2 == 0) {
                    j--;
                }
                if (i < j) {
                    int tmp = nums[i];
                    nums[i] = nums[j];
                    nums[j] = tmp;
                }
            }
            return nums;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int[] nums = { 1, 2, 3, 4 };
            Solution solution = new Solution();
            Console.WriteLine(String.Join(",", solution.Exchange(nums)));
        }
    }
}
