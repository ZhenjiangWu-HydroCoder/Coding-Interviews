﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 剑指_Offer_17.打印从1到最大的n位数
{
    public class Solution
    {
        public int[] PrintNumbers(int n)
        {
            n = (int)Math.Pow(10, n) - 1;
            int[] res = new int[n];
            for (int i = 1; i <= n; i++) {
                res[i - 1] = i;
            }
            return res;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Solution solution = new Solution();
            Console.WriteLine(String.Join(",",solution.PrintNumbers(1)));
        }
    }
}
