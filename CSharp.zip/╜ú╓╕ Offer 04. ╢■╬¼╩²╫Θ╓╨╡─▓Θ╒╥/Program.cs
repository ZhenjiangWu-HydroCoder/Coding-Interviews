﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 剑指_Offer_04.二维数组中的查找
{
    public class Solution
    {
        public bool FindNumberIn2DArray(int[][] matrix, int target)
        {
            if (matrix.Length == 0) return false;
            int i = matrix.Length - 1;
            int j = 0;
            while(i >= 0 && j < matrix[0].Length) {
                if (matrix[i][j] > target) i--;
                else if (matrix[i][j] < target) j++;
                else return true;
            }
            return false;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int[][] matrix = new int[5][];
            matrix[0] = new int[] { 1, 4, 7, 11, 15 };
            matrix[1] = new int[] { 2, 5, 8, 12, 19 };
            matrix[2] = new int[] { 3, 6, 9, 16, 22 };
            matrix[3] = new int[] { 10, 13, 14, 17, 24 };
            matrix[4] = new int[] { 18, 21, 23, 26, 30 };
            int target = 5;
            Solution solution = new Solution();
            Console.WriteLine(solution.FindNumberIn2DArray(matrix, target));
        }
    }
}
