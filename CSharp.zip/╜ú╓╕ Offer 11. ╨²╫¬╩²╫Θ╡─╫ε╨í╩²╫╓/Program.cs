﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 剑指_Offer_11.旋转数组的最小数字
{
    public class Solution
    {
        public int MinArray(int[] numbers)
        {
            if (numbers.Length == 0) return -1;
            int n = numbers.Length - 1;
            while (n != 0 && numbers[0] == numbers[n]) {
                n--;
            }
            if (numbers[0] <= numbers[n]) return numbers[0];
            int l = 0;
            int r = n;
            while (l < r) {
                int mid = (l + r) >> 1;
                if (numbers[mid] < numbers[0]) {
                    r = mid;
                }
                else {
                    l = mid + 1;
                }
            }
            return numbers[r];
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 3, 4, 5, 1, 2 };
            Solution solution = new Solution();
            Console.WriteLine(solution.MinArray(numbers));
        }
    }
}
