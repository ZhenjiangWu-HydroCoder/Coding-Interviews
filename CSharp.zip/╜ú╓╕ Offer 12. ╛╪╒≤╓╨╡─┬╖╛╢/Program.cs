﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 剑指_Offer_12.矩阵中的路径
{
    public class Solution
    {
        private bool dfs(char[][] board, string word, int i, int j, int k, int n, int m)
        {
            if (i < 0 || i >= n || j < 0 || j >= m || board[i][j] != word[k]) {
                return false;
            }
            if (k == word.Length - 1) {
                return true;
            }
            board[i][j] = ' ';
            bool res = dfs(board, word, i + 1, j, k + 1, n, m) || dfs(board, word, i - 1, j, k + 1, n, m) || dfs(board, word, i, j + 1, k + 1, n, m) || dfs(board, word, i, j - 1, k + 1, n, m);
            board[i][j] = word[k];
            return res;
        }

        public bool Exist(char[][] board, string word)
        {
            int n = board.Length;
            int m = board[0].Length;
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {
                    if (dfs(board, word, i, j, 0, n, m)) {
                        return true;
                    }
                }
            }
            return false;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            char[][] board = new char[3][];
            board[0] = new char[] { 'A', 'B', 'C', 'E' };
            board[1] = new char[] { 'S', 'F', 'C', 'S' };
            board[2] = new char[] { 'A', 'D', 'E', 'E' };
            string word = "ABCCED";
            Solution solution = new Solution();
            Console.WriteLine(solution.Exist(board, word));
        }
    }
}
