﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 剑指_Offer_09.用两个栈实现队列
{
    public class CQueue
    {
        private Stack<int> stack;
        private Stack<int> cache;
        public CQueue()
        {
            stack = new Stack<int>();
            cache = new Stack<int>();
        }

        public void AppendTail(int value)
        {
            stack.Push(value);
        }

        public int DeleteHead()
        {
            if (cache.Count != 0) {
                return cache.Pop();
            }
            if (stack.Count == 0) {
                return -1;
            }
            while(stack.Count != 0) {
                cache.Push(stack.Pop());
            }
            return cache.Pop();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
