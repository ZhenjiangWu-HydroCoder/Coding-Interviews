﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 剑指_Offer_22.链表中倒数第k个节点
{
    public class ListNode
    {
        public int val;
        public ListNode next;
        public ListNode(int x) { val = x; }
    }

    public class Solution
    {
        public ListNode GetKthFromEnd(ListNode head, int k)
        {
            if (head == null) return null;
            var former = head;
            var latter = head;
            for (int i = 0; i < k; i++) {
                former = former.next;
            }
            while (former != null) {
                latter = latter.next;
                former = former.next;
            }
            return latter;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
