﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 剑指_Offer_06.从尾到头打印链表
{
    public class ListNode
    {
        public int val;
        public ListNode next;
        public ListNode(int x) { val = x; }
    }

    public class Solution
    {
        public int[] ReversePrint(ListNode head)
        {
            List<int> stack = new List<int>();
            ListNode p = head;
            while(p != null) {
                stack.Add(p.val);
                p = p.next;
            }
            stack.Reverse();
            return stack.ToArray();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
