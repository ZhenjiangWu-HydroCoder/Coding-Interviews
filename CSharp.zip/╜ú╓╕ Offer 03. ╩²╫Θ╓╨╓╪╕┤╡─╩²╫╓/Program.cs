﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 剑指_Offer_03.数组中重复的数字
{
    public class Solution
    {
        public int FindRepeatNumber(int[] nums)
        {
            if (nums.Length == 0) return -1;
            int i = 0;
            while(i < nums.Length) {
                if(nums[i] == i) {
                    i++;
                    continue;
                }
                if (nums[nums[i]] == nums[i]) return nums[i];
                int tmp = nums[nums[i]];
                nums[nums[i]] = nums[i];
                nums[i] = tmp;
            }
            return -1;

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int[] nums = { 2, 3, 1, 0, 2, 5, 3 };
            Solution solution = new Solution();
            Console.WriteLine(solution.FindRepeatNumber(nums));
        }
    }
}
