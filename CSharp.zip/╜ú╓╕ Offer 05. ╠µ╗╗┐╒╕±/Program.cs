﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 剑指_Offer_05.替换空格
{
    public class Solution
    {
        public string ReplaceSpace(string s)
        {
            return s.Replace(" ", "%20");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Solution solution = new Solution();
            Console.WriteLine(solution.ReplaceSpace("We are happy."));
        }
    }
}
