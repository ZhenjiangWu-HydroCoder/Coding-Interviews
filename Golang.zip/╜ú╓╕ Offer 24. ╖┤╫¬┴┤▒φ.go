package main

func reverseList(head *ListNode) *ListNode {
	if head == nil{
		return head
	}
	a := head
	b := head.Next
	for ;b != nil;{
		c := b.Next
		b.Next = a
		a = b
		b = c
	}
	head.Next = nil
	return a
}
