package main

type TreeNode struct {
	Val   int
	Left  *TreeNode
	Right *TreeNode
}

func buildTree(preorder []int, inorder []int) *TreeNode {
	if len(preorder) == 0 {
		return nil
	}
	node := &TreeNode{preorder[0], nil, nil}
	index := 0
	for ; index < len(inorder); index++ {
		if preorder[0] == inorder[index] {
			break
		}
	} // 显然没有python的index函数好用！
	leftPre := preorder[1 : index+1]
	leftIn := inorder[:index]
	rightPre := preorder[index+1:]
	rightIn := inorder[index+1:]
	node.Left = buildTree(leftPre, leftIn)
	node.Right = buildTree(rightPre, rightIn)
	return node
}
