package main

func getKthFromEnd(head *ListNode, k int) *ListNode {
	if head == nil {
		return head
	}
	former := head
	latter := head
	for i := 0; i < k; i++ {
		former = former.Next
	}
	for ; former != nil; {
		latter = latter.Next
		former = former.Next
	}
	return latter
}
