package main

import "fmt"

func exchange(nums []int) []int {
	if len(nums) == 0 {
		return []int{}
	}
	var i = 0
	var j = len(nums) - 1
	for ; i < j; {
		for ; i < j && nums[i]%2 == 1; {
			i++
		}
		for ; i < j && nums[j]%2 == 0; {
			j--
		}
		if i < j {
			tmp := nums[i]
			nums[i] = nums[j]
			nums[j] = tmp
		}
	}
	return nums
}

func main() {
	nums := []int{1, 2, 3, 4}
	fmt.Println(exchange(nums))
}
