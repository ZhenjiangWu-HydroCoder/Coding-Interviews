package main

import "fmt"

func numWays(n int) int {
	var a, b = 1, 1
	for i := 0; i < n; i++ {
		a, b = b, (a+b)%1000000007
	}
	return a
}

func main() {
	fmt.Println(numWays(92))
}
