package main

import "fmt"

func replaceSpace(s string) string {
	var newS []byte
	for i := range s {
		if s[i] == ' ' {
			newS = append(newS, '%', '2', '0')
		} else {
			newS = append(newS, s[i])
		}
	}
	return string(newS)
}

func main()  {
	s := "We are happy."
	res := replaceSpace(s)
	fmt.Println(res)
}
