package main

func deleteNode(head *ListNode, val int) *ListNode {
	if head.Val == val {
		return head.Next
	}
	var pre = head
	var cur = head.Next
	for ; cur != nil && cur.Val != val; {
		pre = pre.Next
		cur = cur.Next
	}
	if cur != nil {
		pre.Next = cur.Next
	}
	return head
}
