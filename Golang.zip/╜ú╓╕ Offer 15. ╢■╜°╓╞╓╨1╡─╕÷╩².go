package main

import "fmt"

func hammingWeight(num uint32) int {
	numNew := int(num)
	res := 0
	for ; numNew > 0; {
		res += int(numNew) & 1
		numNew >>= 1
	}
	return res
}

func main() {
	fmt.Println(hammingWeight(11))
}
