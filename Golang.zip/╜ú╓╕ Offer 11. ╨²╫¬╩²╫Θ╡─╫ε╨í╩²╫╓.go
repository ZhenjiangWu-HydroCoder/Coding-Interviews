package main

import "fmt"

func minArray(numbers []int) int {
	if len(numbers) == 0 {
		return -1
	}
	n := len(numbers) - 1
	for ; n > 0 && numbers[0] == numbers[n]; {
		n--
	}
	if numbers[0] <= numbers[n] {
		return numbers[0]
	}
	l := 0
	r := n
	for ; l < r; {
		mid := (l + r) >> 1
		if numbers[mid] < numbers[0] {
			r = mid
		} else {
			l = mid + 1
		}
	}
	return numbers[r]
}

func main() {
	numbers := []int{2, 2, 2, 0, 1}
	fmt.Println(minArray(numbers))
}
